export const RED = '#f44';
export const BLUE = '#1989fa';
export const GREEN = '#07c160';
